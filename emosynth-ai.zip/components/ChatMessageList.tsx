
import React, { useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import { EMOTION_MAP } from '../constants';

interface ChatMessageListProps {
  messages: ChatMessage[];
  onDeleteMessage: (id: string) => void;
  onClearAll: () => void;
}

const ChatMessageList: React.FC<ChatMessageListProps> = ({ messages, onDeleteMessage, onClearAll }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div 
      ref={scrollRef}
      className="h-full overflow-y-auto px-4 md:px-8 py-6 space-y-8 scroll-smooth"
    >
      {messages.length === 0 ? (
        <div className="h-full flex flex-col items-center justify-center text-center px-8 animate-in fade-in duration-1000">
          <p className="text-white/30 text-base md:text-xl font-outfit font-light max-w-sm leading-relaxed italic">
            "Every heartbeat in this digital space is meant for you. Speak your mind, I'm listening."
          </p>
          <div className="mt-8 w-px h-12 bg-gradient-to-b from-white/20 to-transparent" />
        </div>
      ) : (
        <div className="flex justify-center mb-10">
          <button 
            onClick={onClearAll}
            className="text-[10px] uppercase tracking-[0.2em] font-bold text-white/20 hover:text-white/50 transition-colors bg-white/5 px-4 py-2 rounded-full border border-white/5 active:scale-95"
          >
            Clear History
          </button>
        </div>
      )}
      
      {messages.map((msg) => {
        const isUser = msg.role === 'user';
        const profile = msg.emotion ? EMOTION_MAP[msg.emotion] : null;

        return (
          <div 
            key={msg.id} 
            className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} animate-in slide-in-from-bottom-2 duration-300 group`}
          >
            <div className={`relative max-w-[90%] md:max-w-[75%] rounded-[1.5rem] md:rounded-[2rem] p-5 md:p-6 transition-all duration-300 shadow-lg ${
              isUser 
                ? 'bg-white/10 text-white backdrop-blur-md border border-white/10 rounded-tr-none' 
                : 'bg-white/[0.03] text-white/90 border border-white/5 rounded-tl-none overflow-hidden'
            }`}>
              {!isUser && profile && (
                 <div className={`absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b ${profile.color} ${profile.secondaryColor}`} />
              )}
              
              <p className="text-[14px] md:text-[16px] leading-relaxed whitespace-pre-wrap font-medium pr-6">{msg.content}</p>
              
              {!isUser && msg.emotion && (
                <div className="mt-4 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.1em] text-white/30">
                  <span className="text-base">{profile?.icon}</span>
                  <span className="bg-white/5 px-2 py-0.5 rounded-full border border-white/5">{profile?.label}</span>
                </div>
              )}

              {/* Individual Delete Button - Positioned inside for safety */}
              <button 
                onClick={(e) => {
                  e.preventDefault();
                  onDeleteMessage(msg.id);
                }}
                className={`absolute top-4 right-3 p-1.5 rounded-lg text-red-400 opacity-0 group-hover:opacity-100 transition-all hover:bg-red-500/20 active:scale-90`}
                title="Delete message"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
              </button>
            </div>
            <span className="text-[9px] md:text-[10px] text-white/20 mt-2 px-2 font-bold tracking-wider">
              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        );
      })}
      <div className="h-4 w-full" />
    </div>
  );
};

export default ChatMessageList;
