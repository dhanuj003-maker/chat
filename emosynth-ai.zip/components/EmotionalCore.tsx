
import React from 'react';
import { EmotionType } from '../types';
import { EMOTION_MAP } from '../constants';

interface EmotionalCoreProps {
  emotion: EmotionType;
  intensity: number;
  isThinking: boolean;
}

const EmotionalCore: React.FC<EmotionalCoreProps> = ({ emotion, intensity, isThinking }) => {
  const profile = EMOTION_MAP[emotion];
  
  // Calculate size and speed based on intensity
  const scale = 0.8 + (intensity * 0.4);
  const pulseDuration = isThinking ? '1.5s' : `${3 - intensity * 2}s`;

  return (
    <div className="relative flex items-center justify-center w-full h-full">
      {/* Background Glow */}
      <div 
        className={`absolute w-64 h-64 rounded-full blur-[80px] transition-all duration-1000 ease-in-out`}
        style={{ 
          backgroundColor: profile.glowColor,
          transform: `scale(${scale})`,
          opacity: isThinking ? 0.8 : 0.4 
        }}
      />

      {/* Main Core Orb */}
      <div 
        className={`relative w-40 h-40 md:w-56 md:h-56 rounded-full overflow-hidden transition-all duration-1000 ease-in-out shadow-2xl`}
        style={{ transform: `scale(${scale})` }}
      >
        <div 
          className={`absolute inset-0 bg-gradient-to-tr ${profile.color} ${profile.secondaryColor} animate-pulse`}
          style={{ animationDuration: pulseDuration }}
        />
        
        {/* Swirling Detail */}
        <div 
          className="absolute inset-0 opacity-30 mix-blend-overlay animate-spin"
          style={{ 
            backgroundImage: 'radial-gradient(circle, white 1%, transparent 20%)', 
            backgroundSize: '20px 20px',
            animationDuration: isThinking ? '5s' : '20s'
          }}
        />

        {/* Inner Light */}
        <div className="absolute inset-0 bg-white/20 blur-xl scale-75 rounded-full translate-x-4 -translate-y-4" />
      </div>

      {/* Status Label */}
      <div className="absolute bottom-[-60px] flex flex-col items-center">
        <span className="text-sm font-light tracking-[0.3em] uppercase opacity-50 mb-1">State</span>
        <div className="flex items-center gap-2">
           <span className="text-xl">{profile.icon}</span>
           <span className="text-2xl font-outfit font-semibold text-white/90">{profile.label}</span>
        </div>
        {isThinking && (
          <div className="mt-2 flex gap-1">
            <div className="w-1.5 h-1.5 bg-white rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
            <div className="w-1.5 h-1.5 bg-white rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
            <div className="w-1.5 h-1.5 bg-white rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
          </div>
        )}
      </div>
    </div>
  );
};

export default EmotionalCore;
