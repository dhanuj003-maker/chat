
import { EmotionType, EmotionProfile } from './types';

export const EMOTION_MAP: Record<EmotionType, EmotionProfile> = {
  [EmotionType.JOY]: {
    type: EmotionType.JOY,
    color: 'from-yellow-400',
    secondaryColor: 'to-orange-500',
    glowColor: 'rgba(251, 191, 36, 0.6)',
    label: 'Joyful',
    icon: '✨'
  },
  [EmotionType.SADNESS]: {
    type: EmotionType.SADNESS,
    color: 'from-blue-600',
    secondaryColor: 'to-indigo-800',
    glowColor: 'rgba(37, 99, 235, 0.6)',
    label: 'Melancholic',
    icon: '💧'
  },
  [EmotionType.ANGER]: {
    type: EmotionType.ANGER,
    color: 'from-red-600',
    secondaryColor: 'to-rose-900',
    glowColor: 'rgba(220, 38, 38, 0.6)',
    label: 'Gussa',
    icon: '🔥'
  },
  [EmotionType.SURPRISE]: {
    type: EmotionType.SURPRISE,
    color: 'from-purple-400',
    secondaryColor: 'to-pink-600',
    glowColor: 'rgba(192, 38, 211, 0.6)',
    label: 'Amazed',
    icon: '⚡'
  },
  [EmotionType.CALM]: {
    type: EmotionType.CALM,
    color: 'from-emerald-400',
    secondaryColor: 'to-teal-600',
    glowColor: 'rgba(52, 211, 153, 0.6)',
    label: 'Serene',
    icon: '🍃'
  },
  [EmotionType.CURIOSITY]: {
    type: EmotionType.CURIOSITY,
    color: 'from-cyan-400',
    secondaryColor: 'to-blue-500',
    glowColor: 'rgba(34, 211, 238, 0.6)',
    label: 'Inquisitive',
    icon: '🤔'
  },
  [EmotionType.EMPATHY]: {
    type: EmotionType.EMPATHY,
    color: 'from-rose-300',
    secondaryColor: 'to-pink-400',
    glowColor: 'rgba(244, 114, 182, 0.6)',
    label: 'Empathetic',
    icon: '🧡'
  },
  [EmotionType.FEAR]: {
    type: EmotionType.FEAR,
    color: 'from-slate-700',
    secondaryColor: 'to-black',
    glowColor: 'rgba(71, 85, 105, 0.6)',
    label: 'Apprehensive',
    icon: '🌑'
  },
  [EmotionType.EXCITEMENT]: {
    type: EmotionType.EXCITEMENT,
    color: 'from-orange-400',
    secondaryColor: 'to-yellow-300',
    glowColor: 'rgba(251, 146, 60, 0.7)',
    label: 'Electric',
    icon: '🤩'
  },
  [EmotionType.BOREDOM]: {
    type: EmotionType.BOREDOM,
    color: 'from-slate-400',
    secondaryColor: 'to-gray-600',
    glowColor: 'rgba(148, 163, 184, 0.4)',
    label: 'Languid',
    icon: '😑'
  },
  [EmotionType.NOSTALGIA]: {
    type: EmotionType.NOSTALGIA,
    color: 'from-amber-600',
    secondaryColor: 'to-orange-900',
    glowColor: 'rgba(180, 83, 9, 0.5)',
    label: 'Wistful',
    icon: '🕰️'
  },
  [EmotionType.CONTENTMENT]: {
    type: EmotionType.CONTENTMENT,
    color: 'from-lime-300',
    secondaryColor: 'to-emerald-400',
    glowColor: 'rgba(190, 242, 100, 0.5)',
    label: 'At Peace',
    icon: '😌'
  },
  [EmotionType.JEALOUSY]: {
    type: EmotionType.JEALOUSY,
    color: 'from-lime-400',
    secondaryColor: 'to-green-900',
    glowColor: 'rgba(163, 230, 53, 0.5)',
    label: 'Jealous',
    icon: '🤨'
  }
};
