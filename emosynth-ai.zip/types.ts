
export enum EmotionType {
  JOY = 'JOY',
  SADNESS = 'SADNESS',
  ANGER = 'ANGER',
  SURPRISE = 'SURPRISE',
  CALM = 'CALM',
  CURIOSITY = 'CURIOSITY',
  EMPATHY = 'EMPATHY',
  FEAR = 'FEAR',
  EXCITEMENT = 'EXCITEMENT',
  BOREDOM = 'BOREDOM',
  NOSTALGIA = 'NOSTALGIA',
  CONTENTMENT = 'CONTENTMENT',
  JEALOUSY = 'JEALOUSY'
}

export type PersonaType = 'assistant' | 'girlfriend' | 'boyfriend' | 'best_friend';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  emotion?: EmotionType;
  timestamp: number;
}

export interface EmotionProfile {
  type: EmotionType;
  color: string;
  secondaryColor: string;
  glowColor: string;
  label: string;
  icon: string;
}

export interface GeminiResponse {
  text: string;
  emotion: EmotionType;
  intensity: number;
  thought?: string;
}

export interface AppConfig {
  aiName: string;
  userName: string;
  persona: PersonaType;
}
