
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { ChatMessage, EmotionType, GeminiResponse, PersonaType } from './types';
import { sendMessageToGemini, transcribeAudio } from './services/geminiService';
import EmotionalCore from './components/EmotionalCore';
import ChatMessageList from './components/ChatMessageList';
import PersonaIcon from './components/PersonaIcon';
import { EMOTION_MAP } from './constants';

const PERSONAS: { id: PersonaType; label: string }[] = [
  { id: 'assistant', label: 'Assistant' },
  { id: 'best_friend', label: 'Bestie' },
  { id: 'girlfriend', label: 'Girlfriend' },
  { id: 'boyfriend', label: 'Boyfriend' },
];

const DEFAULT_AI_NAME = 'EmoSynth';
const DEFAULT_USER_NAME = 'User';

const App: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [currentEmotion, setCurrentEmotion] = useState<EmotionType>(EmotionType.CALM);
  const [currentIntensity, setCurrentIntensity] = useState(0.5);
  const [isThinking, setIsThinking] = useState(false);
  const [lastThought, setLastThought] = useState<string | null>(null);
  const [showThought, setShowThought] = useState(false);
  const [persona, setPersona] = useState<PersonaType>('assistant');
  
  // Voice Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Confirmation state for Clear All
  const [isConfirmingClear, setIsConfirmingClear] = useState(false);
  
  // Identity state
  const [aiName, setAiName] = useState(DEFAULT_AI_NAME);
  const [userName, setUserName] = useState(DEFAULT_USER_NAME);
  const [showSettings, setShowSettings] = useState(false);

  const thoughtTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Auto-cancel "Clear All" confirmation after 3 seconds of inactivity
  useEffect(() => {
    if (isConfirmingClear) {
      const timer = setTimeout(() => setIsConfirmingClear(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [isConfirmingClear]);

  const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setIsTranscribing(true);
        const base64Audio = await blobToBase64(audioBlob);
        const transcription = await transcribeAudio(base64Audio, 'audio/webm');
        if (transcription) {
          setInput(prev => prev ? `${prev} ${transcription}` : transcription);
        }
        setIsTranscribing(false);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Microphone access denied:", err);
      alert("Please allow microphone access to use voice messaging.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isThinking) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsThinking(true);
    setShowThought(false);

    const response = await sendMessageToGemini([...messages, userMsg], input, persona, aiName, userName);

    const assistantMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: response.text,
      emotion: response.emotion,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, assistantMsg]);
    setCurrentEmotion(response.emotion);
    setCurrentIntensity(response.intensity);
    
    if (response.thought) {
      setLastThought(response.thought);
      setShowThought(true);
      if (thoughtTimeoutRef.current) clearTimeout(thoughtTimeoutRef.current);
      thoughtTimeoutRef.current = setTimeout(() => setShowThought(false), 8000);
    } else {
      setLastThought(null);
      setShowThought(false);
    }
    
    setIsThinking(false);
  };

  const deleteMessage = (id: string) => {
    setMessages(prev => prev.filter(m => m.id !== id));
  };

  const executeClearAll = () => {
    setMessages([]);
    setLastThought(null);
    setShowThought(false);
    setIsThinking(false);
    setCurrentEmotion(EmotionType.CALM);
    setCurrentIntensity(0.5);
    setIsConfirmingClear(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const activeProfile = EMOTION_MAP[currentEmotion];

  return (
    <div className="flex flex-col h-screen lg:flex-row bg-black overflow-hidden emotion-gradient-transition selection:bg-white/20 font-sans">
      {/* Dynamic Background */}
      <div 
        className="fixed inset-0 pointer-events-none opacity-20 transition-all duration-[2000ms] z-0"
        style={{ 
          background: `radial-gradient(circle at 30% 30%, ${activeProfile.glowColor} 0%, transparent 70%)` 
        }}
      />

      {/* SIDEBAR */}
      <aside className="relative h-[38vh] lg:h-full lg:w-[35%] xl:w-[30%] flex flex-col items-center justify-center border-b lg:border-b-0 lg:border-r border-white/10 z-10 shrink-0 bg-black/40 backdrop-blur-sm">
        <div className="absolute top-4 lg:top-10 left-6 lg:left-10 flex flex-col z-30">
          <h1 className="text-xl lg:text-3xl font-outfit font-extrabold tracking-tighter text-white">
            {aiName.toUpperCase()}
          </h1>
          <div className="flex items-center gap-2 mt-1">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <p className="text-[9px] lg:text-[11px] text-white/40 tracking-[0.3em] uppercase font-bold">Neural Core v7</p>
          </div>
        </div>

        <div className="w-full h-full flex items-center justify-center scale-[0.65] md:scale-90 lg:scale-100 transition-transform duration-700">
          <EmotionalCore 
            emotion={currentEmotion} 
            intensity={currentIntensity} 
            isThinking={isThinking} 
          />
        </div>
      </aside>

      {/* MAIN CHAT AREA */}
      <main className="flex-1 flex flex-col h-[62vh] lg:h-full bg-white/[0.02] backdrop-blur-2xl z-20 relative">
        <header className="px-6 py-4 border-b border-white/5 flex justify-between items-center bg-black/20 backdrop-blur-md">
          <div className="flex items-center gap-3 relative">
            <div className={`p-2 rounded-lg bg-gradient-to-br ${activeProfile.color} ${activeProfile.secondaryColor} shadow-lg transition-all duration-700`}>
              <PersonaIcon type={persona} isActive={true} className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-xs font-bold text-white/90 tracking-wide uppercase">{aiName}</p>
                {isThinking && (
                  <div className="flex gap-1 mb-0.5">
                    <div className="w-1 h-1 bg-white/40 rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <div className="w-1 h-1 bg-white/40 rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <div className="w-1 h-1 bg-white/40 rounded-full animate-bounce" />
                  </div>
                )}
              </div>
              <p className="text-[10px] text-white/40 font-medium">{activeProfile.label} Mode</p>
            </div>
          </div>
          
          <div className="flex gap-2">
            {messages.length > 0 && (
              <button 
                onClick={() => isConfirmingClear ? executeClearAll() : setIsConfirmingClear(true)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all border shadow-lg ${
                  isConfirmingClear 
                    ? 'bg-red-500 text-white border-red-400 scale-105 animate-pulse' 
                    : 'bg-red-500/10 hover:bg-red-500/20 text-red-500 border-red-500/20'
                }`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                <span className="text-[10px] font-extrabold uppercase tracking-widest hidden sm:inline">
                  {isConfirmingClear ? 'Confirm Clear?' : 'Clear Chat'}
                </span>
              </button>
            )}

            <button 
              onClick={() => setShowSettings(true)}
              className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white shadow-xl flex items-center gap-2 transition-all border border-white/10"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
              <span className="text-[11px] font-bold uppercase hidden sm:inline">Settings</span>
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-hidden">
          <ChatMessageList 
            messages={messages} 
            onDeleteMessage={deleteMessage} 
            onClearAll={() => setIsConfirmingClear(true)} 
          />
        </div>

        <footer className="p-4 lg:p-10 border-t border-white/5 bg-black/40 backdrop-blur-3xl">
          <div className="relative max-w-4xl mx-auto flex flex-col gap-2">
            {isTranscribing && (
              <div className="flex items-center gap-2 px-4 py-1 text-[10px] text-white/40 font-bold uppercase tracking-widest animate-pulse">
                <div className="w-1 h-1 bg-white/40 rounded-full" />
                Processing Voice Core...
              </div>
            )}
            <div className="flex gap-3 items-end">
              <div className="relative flex-1">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={isRecording ? "Listening..." : `Tell ${aiName} something...`}
                  className={`w-full bg-white/[0.04] border border-white/10 rounded-[2rem] px-6 py-4 pr-14 text-[15px] lg:text-[17px] focus:outline-none focus:ring-2 focus:ring-white/10 resize-none transition-all placeholder:text-white/20 min-h-[58px] ${isRecording ? 'ring-2 ring-red-500/30' : ''}`}
                  rows={1}
                />
                
                <div className="absolute right-2.5 bottom-2.5 flex items-center gap-2">
                  <button
                    onClick={isRecording ? stopRecording : startRecording}
                    className={`p-3.5 rounded-full transition-all ${
                      isRecording 
                        ? 'bg-red-500 text-white shadow-[0_0_20px_rgba(239,68,68,0.5)] animate-pulse' 
                        : 'bg-white/5 text-white/40 hover:bg-white/10 hover:text-white/80 active:scale-90'
                    }`}
                    title={isRecording ? "Stop Recording" : "Voice Message"}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/>
                      <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                      <line x1="12" y1="19" x2="12" y2="22"/>
                    </svg>
                  </button>
                  
                  <button
                    onClick={handleSend}
                    disabled={!input.trim() || isThinking || isRecording}
                    className={`p-3.5 rounded-3xl transition-all ${
                      input.trim() && !isThinking && !isRecording ? 'bg-white text-black shadow-2xl scale-100 active:scale-90' : 'bg-white/5 text-white/5 cursor-not-allowed scale-90 opacity-20'
                    }`}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </footer>

        {/* SETTINGS DRAWER */}
        {showSettings && (
          <div className="fixed inset-0 z-[100] flex justify-end">
            <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={() => setShowSettings(false)} />
            <div className="relative w-full max-w-md h-full bg-[#050505] border-l border-white/10 shadow-2xl p-8 lg:p-10 animate-in slide-in-from-right duration-500 flex flex-col">
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-2xl font-outfit font-bold tracking-tight">System Core</h2>
                <button onClick={() => setShowSettings(false)} className="p-2 hover:bg-white/10 rounded-full text-white/40 transition-colors"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
              </div>

              <div className="space-y-8">
                <div className="space-y-4">
                  <p className="text-[10px] uppercase tracking-[0.2em] text-white/20 font-extrabold mb-2">Neural Identity</p>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label className="text-[9px] uppercase tracking-widest text-white/40 mb-1.5 block font-bold">AI Identifier</label>
                      <input 
                        type="text" 
                        value={aiName} 
                        onChange={(e) => setAiName(e.target.value)} 
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 focus:bg-white/10 focus:outline-none transition-all font-medium text-white" 
                        placeholder="e.g. EmoSynth"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] uppercase tracking-widest text-white/40 mb-1.5 block font-bold">User Identifier</label>
                      <input 
                        type="text" 
                        value={userName} 
                        onChange={(e) => setUserName(e.target.value)} 
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 focus:bg-white/10 focus:outline-none transition-all font-medium text-white" 
                        placeholder="e.g. User"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <p className="text-[10px] uppercase tracking-[0.2em] text-white/20 font-extrabold mb-2">Neural Persona</p>
                  <div className="grid grid-cols-2 gap-3">
                    {PERSONAS.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => setPersona(p.id)}
                        className={`flex items-center gap-3 p-4 rounded-2xl border transition-all ${
                          persona === p.id 
                            ? 'bg-white/10 border-white/20 text-white shadow-lg ring-1 ring-white/10' 
                            : 'bg-white/[0.02] border-white/5 text-white/30 hover:bg-white/[0.05] hover:text-white/60 active:scale-95'
                        }`}
                      >
                        <PersonaIcon type={p.id} isActive={persona === p.id} className="w-5 h-5" />
                        <span className="text-xs font-bold uppercase tracking-wider">{p.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-auto pt-10 border-t border-white/5">
                <p className="text-[11px] text-white/15 italic leading-relaxed text-center">
                  Changes to core identity and persona influence neural processing in real-time.
                </p>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
